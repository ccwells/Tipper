//
//  ViewController.swift
//  TipCalculator
//
//  Created by Atikur Rahman on 4/5/15.
//  Copyright (c) 2015 Atikur Rahman. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    // MARK: - Outlets

    @IBOutlet weak var billAmountTextField: UITextField!
    @IBOutlet weak var tipPercentTextField: UITextField!
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    @IBOutlet weak var totalAmountLabel: UILabel!
    
    @IBOutlet weak var splitSlider: UISlider!
    @IBOutlet weak var splitCountLabel: UILabel!
    @IBOutlet weak var splitTotalLabel: UILabel!
    
    
    // MARK: - Actions
    
    @IBAction func splitCountChanged(sender: UISlider) {
        splitCountLabel.text = "\(Int(sender.value))"
        calculateTipAndUpdateLabels()
    }
    
    // MARK: -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setNeedsStatusBarAppearanceUpdate()
    }
    
    // change status bar style
    override func preferredStatusBarStyle() -> UIStatusBarStyle {
        return UIStatusBarStyle.LightContent
    }
    
    // hide keyboard when user touches anywhere except text fields
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        billAmountTextField.resignFirstResponder()
        tipPercentTextField.resignFirstResponder()
    }
    
    // calculate tip and update labels
    func calculateTipAndUpdateLabels() {
        let billAmount = (billAmountTextField.text as NSString).doubleValue
        let tipPercent = (tipPercentTextField.text as NSString).integerValue
        
        let tipAmount = (billAmount * Double(tipPercent))/100
        let totalAmount = billAmount + tipAmount
        
        let splitCount = Int(splitSlider.value)
        let splitTotal = totalAmount/Double(splitCount)
        
        tipAmountLabel.text = String(format: "$%.2f", tipAmount)
        totalAmountLabel.text = String(format: "$%.2f", totalAmount)
        splitTotalLabel.text = String(format: "$%.2f", splitTotal)
    }
    
    // MARK: - UITextFieldDelegate Methods
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        calculateTipAndUpdateLabels()
    }

}

