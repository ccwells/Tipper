//
//  InterfaceController.swift
//  TipCalculator WatchKit Extension
//
//  Created by Atikur Rahman on 4/5/15.
//  Copyright (c) 2015 Atikur Rahman. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet weak var billAmountLabel: WKInterfaceLabel!
    @IBOutlet weak var tipPercentageLabel: WKInterfaceLabel!
    
    var billAmountString: String = "" {
        didSet {
            billAmountLabel.setText(billAmountString)
        }
    }
    
    var tipPercent: Int = 15 {
        didSet {
            tipPercentageLabel.setText("\(tipPercent)%")
        }
    }
    
    // MARK: - Life cycle methods
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        tipPercent = 15
        billAmountString = "0"
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    override func contextForSegueWithIdentifier(segueIdentifier: String) -> AnyObject? {
        if segueIdentifier == "calculateTip" {
            let billAmount = (billAmountString as NSString).doubleValue
            return ["billAmount": billAmount , "tipPercent": tipPercent]
        } else {
            return ["billAmount": 0.0, "tip": 0]
        }
    }
    
    // MARK: - Actions
    
    @IBAction func clearBill() {
        billAmountString = "0"
    }
    
    @IBAction func incrementTipPercentage() {
        if tipPercent < 99 {
            tipPercent++
        }
    }
    
    @IBAction func decrementTipPercentage() {
        if tipPercent > 0 {
            tipPercent--
        }
    }
    
    @IBAction func appendOne() {
        addDigitToDisplay(1)
    }
    
    @IBAction func appendTwo() {
        addDigitToDisplay(2)
    }

    @IBAction func appendThree() {
        addDigitToDisplay(3)
    }
    
    @IBAction func appendFour() {
        addDigitToDisplay(4)
    }
    
    @IBAction func appendFive() {
        addDigitToDisplay(5)
    }
    
    @IBAction func appendSix() {
        addDigitToDisplay(6)
    }
    
    @IBAction func appendSeven() {
        addDigitToDisplay(7)
    }
    
    @IBAction func appendEight() {
        addDigitToDisplay(8)
    }
    
    @IBAction func appendNine() {
        addDigitToDisplay(9)
    }
    
    @IBAction func appendZero() {
        addDigitToDisplay(0)
    }
    
    @IBAction func appendDecimal() {
        // check whether it already contains a decimal point or not
        if billAmountString.rangeOfString(".") == nil {
            // if decimal is the first character, add a leading zero
            if billAmountString.isEmpty {
                addToDisplay("0.")
            } else {
                addToDisplay(".")
            }
        }
    }
    
    func addDigitToDisplay(digit: Int) {
        // if current value is 0, don't need to add additional 0
        if billAmountString != "0" {
            addToDisplay("\(digit)")
        } else {
            billAmountString = "\(digit)"
        }
    }
    
    func addToDisplay(msg: String) {
        billAmountString = billAmountString.stringByAppendingString(msg)
    }
    
}
