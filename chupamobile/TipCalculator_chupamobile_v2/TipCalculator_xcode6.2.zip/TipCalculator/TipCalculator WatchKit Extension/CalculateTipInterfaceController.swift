//
//  CalculateTipInterfaceController.swift
//  TipCalculator
//
//  Created by Atikur Rahman on 4/5/15.
//  Copyright (c) 2015 Atikur Rahman. All rights reserved.
//

import WatchKit
import Foundation


class CalculateTipInterfaceController: WKInterfaceController {

    @IBOutlet weak var billAmountLabel: WKInterfaceLabel!
    @IBOutlet weak var tipAmountLabel: WKInterfaceLabel!
    @IBOutlet weak var totalAmountLabel: WKInterfaceLabel!
    @IBOutlet weak var splitAmountLabel: WKInterfaceLabel!
    
    var totalAmount: Double = 0
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        
        if let billAmount = (context as NSDictionary)["billAmount"] as? Double {
            if let tipPercent = (context as NSDictionary)["tipPercent"] as? Int {
                let tipAmount = (billAmount * Double(tipPercent))/100
                let totalAmount = billAmount + tipAmount
                
                billAmountLabel.setText(String(format: "$%.2f", billAmount))
                tipAmountLabel.setText(String(format: "$%.2f", tipAmount))
                totalAmountLabel.setText(String(format: "$%.2f", totalAmount))
                splitAmountLabel.setText("")
                
                self.totalAmount = totalAmount
            }
        } else {
            billAmountLabel.setText("")
            tipAmountLabel.setText("")
            totalAmountLabel.setText("")
            splitAmountLabel.setText("")
        }
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func splitHalf() {
        setSplitAmount(totalAmount/2)
    }
    
    @IBAction func splitOneThird() {
        setSplitAmount(totalAmount/3)
    }
   
    @IBAction func splitOneFourth() {
        setSplitAmount(totalAmount/4)
    }
    
    func setSplitAmount(amount: Double) {
        splitAmountLabel.setText(String(format: "$%.2f", amount))
    }
    
}
